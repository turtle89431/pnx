<script>
    /** @type {import('./$types').PageData} */
    export let data;
    let {rustApiCall} =data
  
</script>
<h1>Data from Rust {rustApiCall}</h1>
<p>Visit <a href="https://gaming.guacamolebox.net/">AvoGaming</a> is the page you will be working on</p>
