const {hello} = require("./index.node")
module.exports = {hello}